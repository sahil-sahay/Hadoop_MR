import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

//Extends the default Reducer class with arguments KeyIn as Text and ValueIn as IntWritable 
//which are same as the outputs of the mapper class and KeyOut as Text and ValueOut as IntWritbale 
//which will be final outputs of our MapReduce program.
public class Task3Reducer extends Reducer<Text, IntWritable, Text, IntWritable>
{	
	//Overriding the Reduce method which will run each time for every key.
	public void reduce(Text key, Iterable<IntWritable> values,
		      Context context) throws IOException, InterruptedException
	{
		//Printing Key at standard output to check if output key is as expected
		System.out.println("From The Reducer Key is=>"+key) ;	
	    
		  //Declaring an integer variable sum which will store the sum of all the values for each key.
	      int sum = 0;
	      
	      //A for each loop is taken which will run each time for the values inside the �Iterable values� 
	      //which are coming from the shuffle and sort phase after the mapper phase.
	      for (IntWritable value : values) {
	    	  //storing and calculating the sum of the values.
	    	  sum+=value.get();	
	       }
	       //Writing the respective key and the obtained sum as value to the context to produce final output.
	       context.write(key, new IntWritable(sum));
	  }
	}
