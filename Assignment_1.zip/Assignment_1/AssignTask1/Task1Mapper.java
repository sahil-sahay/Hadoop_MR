import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*; 

//Taking a class by the name Task1Mapper.
//Extending the Mapper default class having the arguments keyIn as 
//LongWritable, ValueIn as Text, KeyOut as Text and ValueOut as Text.

public class Task1Mapper extends Mapper<LongWritable, Text, Text, Text> {
	
	//Overriding the map method which will run one time for every line.
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException {
		
		//Declaring an empty string. As we need to print the whole content of the input file in another variable.
		String empty = "";
		
		//Converting values to string & storing the line in a string variable �line�.
		String line = value.toString();
		
		//Splitting the line by using pipe �|� delimiter. Since pipe is a metacharacter, need to suppress using backslash
		// to treat it as a normal pipe character & hide it's special meaning.
		//and storing the values in a String Array str, so that all the columns in a row are stored in the string array.
		String[] str = line.split("\\|");
		
		//Storing Company name in a variable comp to compare for NA which is at 1st column of str array.
		String comp = str[0];
		
		//Storing Product name in a variable comp to compare for NA which is at 2nd column of str array
		String prod = str[1];
	
		//Printing company & product to debug if the code is working as expected.
		System.err.println("Company : "+comp);
		System.err.println("Product : "+prod);
		
		//Comparing both the values to "NA" if it is not present in a particular string 
		// then only write the value & empty(taken empty as value conatins the actual data & two arguments are mandatory 
		//for context.write) into the context, which will be the output of the map method.
		if (!(comp.equals("NA") || prod.equals("NA"))) {
			context.write(new Text(value), new Text(empty));
		}
	}
}
